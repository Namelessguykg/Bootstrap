function updateDateTime() {
  const now = new Date();
  const update = now.toLocaleString();
  document.getElementById('datetime').innerHTML = update;
}
updateDateTime();
setInterval(updateDateTime, 1000);