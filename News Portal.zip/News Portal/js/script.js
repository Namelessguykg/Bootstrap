function displayDateTime() {
    
    const currentDateTime = new Date(); 

    
    const formattedDateTime = currentDateTime.toLocaleString(); 

    
    const datetimeDisplayElement = document.getElementById('datetime-display'); 

   
    if (datetimeDisplayElement) { 
        datetimeDisplayElement.textContent = formattedDateTime;
    }
}


displayDateTime();


setInterval(displayDateTime, 1000); 
